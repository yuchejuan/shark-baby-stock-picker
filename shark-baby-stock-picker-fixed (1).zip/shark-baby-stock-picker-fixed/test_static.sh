#!/bin/bash
# ============================================================
# 🦈 鯊魚寶寶選股系統 — 靜態分析測試腳本
# 使用方式：bash test_static.sh
# 不需要啟動任何伺服器
# ============================================================

PASS=0; FAIL=0; TOTAL=0
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'

pass() { echo -e "  ${GREEN}✅ PASS${NC} $1"; PASS=$((PASS+1)); TOTAL=$((TOTAL+1)); }
fail() { echo -e "  ${RED}❌ FAIL${NC} $1\n       ${RED}→ $2${NC}"; FAIL=$((FAIL+1)); TOTAL=$((TOTAL+1)); }
info() { echo -e "\n${BLUE}▶ $1${NC}"; }

# 用 if/else 取代 && || 避免 bash 算術展開的 exit code 問題
check() {
    local label="$1" cond="$2" reason="$3"
    if eval "$cond"; then pass "$label"; else fail "$label" "$reason"; fi
}

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
INDEX="$SCRIPT_DIR/html/index.html"
BATCHES="$SCRIPT_DIR/html/portfolio_batches.js"
SIMULATION="$SCRIPT_DIR/html/simulation.js"
DAILY="$SCRIPT_DIR/daily_report.json"
SECTOR="$SCRIPT_DIR/sector_heatmap.json"

echo "============================================================"
echo "  🦈 鯊魚寶寶 — 靜態分析測試"
echo "  $(date '+%Y-%m-%d %H:%M:%S')"
echo "  專案目錄：$SCRIPT_DIR"
echo "============================================================"

# ─────────────────────────────────────────────
info "Suite 1：檔案存在"
# ─────────────────────────────────────────────

declare -A FILE_LABELS
FILE_LABELS["$SCRIPT_DIR/index.html"]="index.html（根目錄）"
FILE_LABELS["$SCRIPT_DIR/html/index.html"]="html/index.html"
FILE_LABELS["$SCRIPT_DIR/html/portfolio_batches.js"]="html/portfolio_batches.js"
FILE_LABELS["$SCRIPT_DIR/html/simulation.js"]="html/simulation.js"
FILE_LABELS["$SCRIPT_DIR/daily_report.json"]="daily_report.json"
FILE_LABELS["$SCRIPT_DIR/sector_heatmap.json"]="sector_heatmap.json"
FILE_LABELS["$SCRIPT_DIR/html/dividend_tracker.html"]="html/dividend_tracker.html"
FILE_LABELS["$SCRIPT_DIR/html/dividend_strategy.html"]="html/dividend_strategy.html"

for fpath in \
    "$SCRIPT_DIR/index.html" \
    "$SCRIPT_DIR/html/index.html" \
    "$SCRIPT_DIR/html/portfolio_batches.js" \
    "$SCRIPT_DIR/html/simulation.js" \
    "$SCRIPT_DIR/daily_report.json" \
    "$SCRIPT_DIR/sector_heatmap.json" \
    "$SCRIPT_DIR/html/dividend_tracker.html" \
    "$SCRIPT_DIR/html/dividend_strategy.html"
do
    label="${FILE_LABELS[$fpath]:-${fpath##*/}}"
    if [ -f "$fpath" ]; then
        pass "存在：$label"
    else
        fail "存在：$label" "找不到 $fpath"
    fi
done

# ─────────────────────────────────────────────
info "Suite 2：index.html — Bug 修正驗證"
# ─────────────────────────────────────────────

HTML=$(cat "$INDEX" 2>/dev/null)

_contains()  { echo "$HTML" | grep -qF "$1"; }
_not_contains() { ! echo "$HTML" | grep -qF "$1"; }

if _contains "switchTab('picks', this)"; then
    pass "FIX#1  switchTab 傳入 this，不再使用隱式 event"
else
    fail "FIX#1  switchTab 傳入 this" "找不到 switchTab('picks', this)"
fi

if _not_contains "window.switchTab = function" && _not_contains "originalSwitchTab"; then
    pass "FIX#2  無 window.switchTab 覆寫"
else
    fail "FIX#2  無 window.switchTab 覆寫" "仍有 window.switchTab 或 originalSwitchTab"
fi

if _contains ".badge-neutral"; then
    pass "FIX#3  badge-neutral CSS 已定義"
else
    fail "FIX#3  badge-neutral CSS" "找不到 .badge-neutral"
fi

if ! echo "$HTML" | grep -q "score >= 80 ? 'positive'"; then
    pass "FIX#4  scoreClass 邏輯已修正（無重複 'positive'）"
else
    fail "FIX#4  scoreClass 邏輯" "仍有 score >= 80 ? 'positive' 重複條件"
fi

if _contains "function buildFIFOMap" && _contains "function calcSellPnL"; then
    pass "FIX#5  FIFO 共用函式存在（buildFIFOMap + calcSellPnL）"
else
    fail "FIX#5  FIFO 共用函式" "找不到 buildFIFOMap 或 calcSellPnL"
fi

if _contains "const CONFIG" && _contains "TRADE_API" && _contains "QUERY_API"; then
    if ! echo "$HTML" | grep -qE "^[[:space:]]*const API_BASE"; then
        pass "FIX#6  CONFIG 物件統一管理 API（無舊版 API_BASE）"
    else
        fail "FIX#6  CONFIG 物件" "仍有舊版 const API_BASE 宣告"
    fi
else
    fail "FIX#6  CONFIG 物件" "找不到 CONFIG / TRADE_API / QUERY_API"
fi

INTERVAL_COUNT=$(echo "$HTML" | grep "setInterval" | grep -v "//.*setInterval" | wc -l | tr -d ' ')
if [ "$INTERVAL_COUNT" -le 1 ]; then
    pass "FIX#7  setInterval 精簡為 ${INTERVAL_COUNT} 個（不含註解）"
else
    fail "FIX#7  setInterval 數量" "有 ${INTERVAL_COUNT} 個，預期 ≤ 1"
fi

ERROR_UI=$(echo "$HTML" | grep -c "error-message")
if [ "$ERROR_UI" -ge 2 ]; then
    pass "FIX#8  載入失敗 UI 存在（${ERROR_UI} 個 error-message 區塊）"
else
    fail "FIX#8  載入失敗 UI" "只有 ${ERROR_UI} 個，預期 ≥ 2"
fi

if _contains "overflow-x" && (echo "$HTML" | grep -qE "min-width:\s*600px|min-width:600px"); then
    pass "FIX#9  行動裝置響應：overflow-x + table min-width"
else
    fail "FIX#9  行動裝置" "缺少 overflow-x 或 table min-width:600px"
fi

if _contains 'id="sell-modal"' && _contains "showSellModal" && _contains "confirmSell"; then
    pass "FIX#10 賣出 Modal 完整（sell-modal + showSellModal + confirmSell）"
else
    fail "FIX#10 賣出 Modal" "缺少 sell-modal / showSellModal / confirmSell"
fi

# ─────────────────────────────────────────────
info "Suite 3：portfolio_batches.js 修正驗證"
# ─────────────────────────────────────────────

BATCHJS=$(cat "$BATCHES" 2>/dev/null)

if ! echo "$BATCHJS" | grep -qF "fetch('http://localhost:8888"; then
    pass "API URL 不再硬編碼"
else
    fail "API URL 硬編碼" "仍有 fetch('http://localhost:8888..."
fi

SM=$(echo "$BATCHJS" | grep -n "return showSellModal" | head -1 | cut -d: -f1)
SK=$(echo "$BATCHJS" | grep -n "return sellStock"     | head -1 | cut -d: -f1)
if [ -n "$SM" ] && [ -n "$SK" ] && [ "$SM" -lt "$SK" ]; then
    pass "showSellModal 優先於 sellStock（行 $SM < $SK）"
else
    fail "showSellModal 優先順序" "return showSellModal@${SM:-?} return sellStock@${SK:-?}"
fi

if echo "$BATCHJS" | grep -q "innerHTML"; then
    pass "loadPortfolio 錯誤時顯示 UI（innerHTML）"
else
    fail "loadPortfolio 錯誤 UI" "找不到 innerHTML 錯誤顯示"
fi

if echo "$BATCHJS" | grep -q "loadPortfolioLegacy"; then
    pass "降級方案 loadPortfolioLegacy 存在"
else
    fail "降級方案" "找不到 loadPortfolioLegacy"
fi

# ─────────────────────────────────────────────
info "Suite 4：simulation.js 修正驗證"
# ─────────────────────────────────────────────

SIMJS=$(cat "$SIMULATION" 2>/dev/null)

if ! echo "$SIMJS" | grep -qE "^const API_BASE"; then
    pass "無頂層 const API_BASE（避免與 CONFIG 衝突）"
else
    fail "移除頂層 API_BASE" "仍有頂層 const API_BASE"
fi

if echo "$SIMJS" | grep -q "showSellModal"; then
    pass "simulateSell 優先使用 showSellModal"
else
    fail "simulateSell showSellModal" "找不到 showSellModal"
fi

if echo "$SIMJS" | grep -q "_SIM_API\|CONFIG"; then
    pass "API URL 使用相容變數（_SIM_API 或 CONFIG）"
else
    fail "API URL 變數" "找不到 _SIM_API 或 CONFIG"
fi

# ─────────────────────────────────────────────
info "Suite 5：JSON 格式與欄位驗證"
# ─────────────────────────────────────────────

for jsonfile in "$DAILY" "$SECTOR" "$SCRIPT_DIR/portfolio.json"; do
    fname="${jsonfile##*/}"
    if [ ! -f "$jsonfile" ]; then
        fail "JSON 存在：$fname" "找不到檔案"
        continue
    fi
    if python3 -c "import json; json.load(open('$jsonfile'))" 2>/dev/null; then
        pass "JSON 語法正確：$fname"
    else
        fail "JSON 語法：$fname" "JSON 解析失敗"
    fi
done

# 驗證 daily_report.json 股票欄位
FIRST_STOCK=$(python3 -c "
import json, sys
try:
    d = json.load(open('$DAILY'))
    picks = d.get('all_picks') or d.get('picks_20_30') or d.get('picks_30_40') or []
    print(json.dumps(picks[0]) if picks else '{}')
except Exception as e:
    print('{}')
" 2>/dev/null)

REQUIRED_FIELDS="symbol name price score rsi macd kd signal advantage ma5 ma20"
for field in $REQUIRED_FIELDS; do
    if echo "$FIRST_STOCK" | grep -q "\"$field\""; then
        pass "daily_report 欄位存在：$field"
    else
        fail "daily_report 欄位：$field" "找不到欄位 $field（資料：${FIRST_STOCK:0:80}...）"
    fi
done

# 驗證 sector_heatmap.json 欄位
FIRST_SECTOR=$(python3 -c "
import json
try:
    d = json.load(open('$SECTOR'))
    s = d.get('all_sectors', [])
    print(json.dumps(s[0]) if s else '{}')
except: print('{}')
" 2>/dev/null)

for field in name change_rate stock_count up_count down_count lead_stocks; do
    if echo "$FIRST_SECTOR" | grep -q "\"$field\""; then
        pass "sector_heatmap 欄位存在：$field"
    else
        fail "sector_heatmap 欄位：$field" "找不到欄位 $field"
    fi
done

# ─────────────────────────────────────────────
info "Suite 6：跨檔案相容性驗證"
# ─────────────────────────────────────────────

# index.html 載入 portfolio_batches.js
if echo "$HTML" | grep -q "portfolio_batches.js"; then
    pass "index.html 引入 portfolio_batches.js"
else
    fail "index.html 引入 portfolio_batches.js" "找不到 <script src>"
fi

# portfolio_batches.js 呼叫 showSellModal（index.html 提供）
if echo "$BATCHJS" | grep -q "showSellModal"; then
    pass "portfolio_batches.js ↔ index.html 賣出介面相容"
else
    fail "跨檔案賣出相容" "portfolio_batches.js 找不到 showSellModal"
fi

# simulation.js API 變數不與 index.html 衝突
if ! echo "$SIMJS" | grep -qE "^const API_BASE|^var API_BASE"; then
    pass "simulation.js 不宣告全域 API_BASE（不與 CONFIG 衝突）"
else
    fail "全域變數衝突" "simulation.js 仍有全域 API_BASE"
fi

# root 與 html/ 子目錄版本一致
ROOT_MD5=$(md5sum "$SCRIPT_DIR/index.html" 2>/dev/null | cut -d' ' -f1)
HTML_MD5=$(md5sum "$SCRIPT_DIR/html/index.html" 2>/dev/null | cut -d' ' -f1)
if [ "$ROOT_MD5" = "$HTML_MD5" ] && [ -n "$ROOT_MD5" ]; then
    pass "根目錄 index.html 與 html/index.html 版本一致（MD5 相符）"
else
    fail "index.html 版本一致性" "根目錄：$ROOT_MD5  html/：$HTML_MD5"
fi

ROOT_PB=$(md5sum "$SCRIPT_DIR/portfolio_batches.js" 2>/dev/null | cut -d' ' -f1)
HTML_PB=$(md5sum "$SCRIPT_DIR/html/portfolio_batches.js" 2>/dev/null | cut -d' ' -f1)
if [ "$ROOT_PB" = "$HTML_PB" ] && [ -n "$ROOT_PB" ]; then
    pass "根目錄 portfolio_batches.js 與 html/ 版本一致"
else
    fail "portfolio_batches.js 版本一致性" "根目錄：$ROOT_PB  html/：$HTML_PB"
fi

# ─────────────────────────────────────────────
echo ""
echo "============================================================"
if [ $FAIL -eq 0 ]; then
    echo -e "  ${GREEN}🎉 全部通過！${NC}  總計：${TOTAL} | ✅ ${PASS} 通過"
else
    echo -e "  總計：${TOTAL} | ${GREEN}✅ 通過：${PASS}${NC} | ${RED}❌ 失敗：${FAIL}${NC}"
    echo -e "  ${RED}⚠️  有 ${FAIL} 個測試失敗，請檢查上方紅色項目${NC}"
fi
echo "============================================================"
exit $FAIL
