#!/bin/bash
# ============================================================
# 🦈 鯊魚寶寶選股系統 — API 連線測試腳本
# 使用方式：bash test_api.sh
# 需要先啟動後端：go run daily_report_web.go &
# ============================================================

PASS=0; FAIL=0; SKIP=0; TOTAL=0
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'

pass() { echo -e "  ${GREEN}✅ PASS${NC} $1"; ((PASS++)); ((TOTAL++)); }
fail() { echo -e "  ${RED}❌ FAIL${NC} $1\n       ${RED}→ $2${NC}"; ((FAIL++)); ((TOTAL++)); }
skip() { echo -e "  ${YELLOW}⚠️  SKIP${NC} $1\n       ${YELLOW}→ $2${NC}"; ((SKIP++)); ((TOTAL++)); }
info() { echo -e "\n${BLUE}▶ $1${NC}"; }

API="http://localhost:8888/api"
QUERY_API="http://localhost:8765/api"
TIMEOUT=5

echo "============================================================"
echo "  🦈 鯊魚寶寶 — API 連線測試"
echo "  $(date '+%Y-%m-%d %H:%M:%S')"
echo "  API: $API"
echo "============================================================"

# 先確認 API 可連線
API_ALIVE=false
curl -sf --max-time 2 "$API/trades" > /dev/null 2>&1 && API_ALIVE=true

if [ "$API_ALIVE" = false ]; then
    echo -e "\n${YELLOW}⚠️  API 伺服器未啟動（Port 8888），請先執行：${NC}"
    echo "    go run daily_report_web.go &"
    echo -e "\n${YELLOW}跳過所有 API 測試。${NC}\n"
    exit 0
fi

echo -e "  ${GREEN}✅ API 伺服器已啟動${NC}\n"

# ────────────────────────────────────
# 工具函式
# ────────────────────────────────────
http_get() {
    curl -sf --max-time $TIMEOUT "$1" 2>&1
}

http_post() {
    curl -sf --max-time $TIMEOUT -X POST \
        -H "Content-Type: application/json" \
        -d "$2" "$1" 2>&1
}

check_json() {
    echo "$1" | python3 -c "import json,sys; json.load(sys.stdin)" 2>/dev/null
    return $?
}

get_field() {
    echo "$1" | python3 -c "import json,sys; d=json.load(sys.stdin); print(d.get('$2',''))" 2>/dev/null
}

# ────────────────────────────────────
info "Suite 1：基礎端點測試"
# ────────────────────────────────────

RESP=$(http_get "$API/trades")
[ $? -eq 0 ] || { fail "GET /trades" "連線失敗"; }
check_json "$RESP" \
    && pass "GET /trades — 回傳有效 JSON" \
    || fail "GET /trades — JSON 格式" "回應：$RESP"

RESP=$(http_get "$API/holdings/batches")
check_json "$RESP" \
    && pass "GET /holdings/batches — 回傳有效 JSON" \
    || fail "GET /holdings/batches" "回應：$RESP"

# ────────────────────────────────────
info "Suite 2：買入交易測試"
# ────────────────────────────────────

BUY_PAYLOAD='{
    "type": "buy",
    "symbol": "AUTOTEST",
    "name": "自動測試股票",
    "shares": 100,
    "price": 88.8,
    "date": "'$(date -u +"%Y-%m-%dT%H:%M:%SZ")'",
    "note": "自動化測試-請忽略"
}'

BUY_RESP=$(http_post "$API/trade/add" "$BUY_PAYLOAD")
check_json "$BUY_RESP" || { fail "POST /trade/add (buy) JSON" "回應：$BUY_RESP"; }

SUCCESS=$(get_field "$BUY_RESP" "success")
[ "$SUCCESS" = "True" ] || [ "$SUCCESS" = "true" ] \
    && pass "POST /trade/add (buy) — success: true" \
    || fail "POST /trade/add (buy)" "success=$SUCCESS 回應：$BUY_RESP"

# 確認買入後可在 trades 裡找到
sleep 0.5
TRADES_RESP=$(http_get "$API/trades")
echo "$TRADES_RESP" | grep -q "AUTOTEST" \
    && pass "買入後出現在 /trades 清單中" \
    || fail "買入後出現在 /trades 清單" "AUTOTEST 找不到"

# ────────────────────────────────────
info "Suite 3：賣出交易測試"
# ────────────────────────────────────

SELL_PAYLOAD='{
    "type": "sell",
    "symbol": "AUTOTEST",
    "name": "自動測試股票",
    "shares": 100,
    "price": 99.9,
    "date": "'$(date -u +"%Y-%m-%dT%H:%M:%SZ")'",
    "note": "自動化測試賣出-請忽略"
}'

SELL_RESP=$(http_post "$API/trade/add" "$SELL_PAYLOAD")
check_json "$SELL_RESP" || { fail "POST /trade/add (sell) JSON" "回應：$SELL_RESP"; }

SUCCESS=$(get_field "$SELL_RESP" "success")
[ "$SUCCESS" = "True" ] || [ "$SUCCESS" = "true" ] \
    && pass "POST /trade/add (sell) — success: true" \
    || fail "POST /trade/add (sell)" "success=$SUCCESS"

# ────────────────────────────────────
info "Suite 4：持倉更新測試"
# ────────────────────────────────────

UPDATE_RESP=$(http_post "$API/holdings/update-prices" '{}')
if [ $? -eq 0 ]; then
    check_json "$UPDATE_RESP" \
        && pass "POST /holdings/update-prices — 回傳有效 JSON" \
        || fail "POST /holdings/update-prices JSON" "回應：$UPDATE_RESP"
else
    skip "POST /holdings/update-prices" "端點可能不存在"
fi

# ────────────────────────────────────
info "Suite 5：查詢 API 測試（Port 8765）"
# ────────────────────────────────────

QUERY_ALIVE=false
curl -sf --max-time 2 "$QUERY_API/query?symbol=2330" > /dev/null 2>&1 && QUERY_ALIVE=true

if [ "$QUERY_ALIVE" = false ]; then
    skip "GET /api/query?symbol=2330" "查詢 API 未啟動（Port 8765）— go run stock_query_api.go &"
else
    QRESP=$(http_get "$QUERY_API/query?symbol=2330")
    check_json "$QRESP" || { fail "GET /query?symbol=2330 JSON" "回應：$QRESP"; }
    SYM=$(get_field "$QRESP" "symbol")
    [ "$SYM" = "2330" ] \
        && pass "查詢 2330 台積電 — symbol 正確" \
        || fail "查詢 2330" "回傳 symbol=$SYM"

    PRICE=$(get_field "$QRESP" "price")
    [ -n "$PRICE" ] && [ "$PRICE" != "0" ] \
        && pass "查詢 2330 — price 有值（$PRICE）" \
        || fail "查詢 2330 price" "price=$PRICE"
fi

# ────────────────────────────────────
info "Suite 6：回應時間測試"
# ────────────────────────────────────

for endpoint in "trades" "holdings/batches"; do
    START=$(date +%s%3N)
    curl -sf --max-time 5 "$API/$endpoint" > /dev/null 2>&1
    END=$(date +%s%3N)
    MS=$((END - START))
    [ "$MS" -lt 2000 ] \
        && pass "GET /$endpoint 回應時間：${MS}ms（< 2000ms）" \
        || fail "GET /$endpoint 回應時間" "${MS}ms 超過 2000ms"
done

# ────────────────────────────────────
echo ""
echo "============================================================"
echo -e "  總計：${TOTAL} | ${GREEN}✅ 通過：${PASS}${NC} | ${RED}❌ 失敗：${FAIL}${NC} | ${YELLOW}⚠️  跳過：${SKIP}${NC}"
[ $FAIL -eq 0 ] \
    && echo -e "  ${GREEN}🎉 所有 API 測試通過！${NC}" \
    || echo -e "  ${RED}⚠️  有 ${FAIL} 個測試失敗${NC}"
echo "============================================================"
exit $FAIL
